#!/bin/sh

sudo cp libBTSerial.so /usr/local/lib

