#!/bin/sh

sudo cp libPPPagSeguro.so /usr/local/lib
sudo cp -r include /usr/local
sudo ./mapbluetostty.sh	

